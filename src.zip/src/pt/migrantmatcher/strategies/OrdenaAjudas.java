package pt.migrantmatcher.strategies;

import java.util.List;

import pt.migrantmatcher.domain.Ajuda;

public interface OrdenaAjudas {
	public List <Ajuda> ordena();
}
