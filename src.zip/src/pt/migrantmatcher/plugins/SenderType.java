package pt.migrantmatcher.plugins;

public interface SenderType {
	
	public void enviaSMS(int num, String cod);
}
