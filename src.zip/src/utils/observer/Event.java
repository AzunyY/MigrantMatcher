package utils.observer;

/**
 * Esta interface define um Evento
 */
public interface Event {
	

}
