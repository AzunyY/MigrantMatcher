package pt.migrantmatcher.exceptios;

@SuppressWarnings("serial")
public class ThereIsNoValueInPropertiesException extends Exception {

}
