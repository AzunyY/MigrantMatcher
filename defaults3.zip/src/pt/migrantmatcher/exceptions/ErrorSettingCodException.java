package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class ErrorSettingCodException extends Exception {

}
