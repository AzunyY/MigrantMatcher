package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class NoFileNameException extends Exception  {

}
