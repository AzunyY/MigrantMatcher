package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class ThereIsNoRegionCatalogoException extends Exception {

}
