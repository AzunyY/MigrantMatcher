package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class PropertiesLoadingException extends Exception {

}
