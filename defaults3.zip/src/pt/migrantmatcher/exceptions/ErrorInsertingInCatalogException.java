package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class ErrorInsertingInCatalogException extends Exception {

}
