package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class RegisterIsNotValidException extends Exception {

}
