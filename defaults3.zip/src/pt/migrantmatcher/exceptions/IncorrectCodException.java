package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class IncorrectCodException extends Exception {

}
