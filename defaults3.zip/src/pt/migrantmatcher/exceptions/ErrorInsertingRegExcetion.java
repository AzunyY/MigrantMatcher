package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class ErrorInsertingRegExcetion extends Exception {

}
