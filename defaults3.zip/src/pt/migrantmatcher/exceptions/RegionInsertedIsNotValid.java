package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class RegionInsertedIsNotValid extends Exception {

}
