package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class AidIsNotValidException extends Exception {	
}

