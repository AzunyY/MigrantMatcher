package pt.migrantmatcher.exceptions;

@SuppressWarnings("serial")
public class AidIsNonExistenceException extends Exception {

}
