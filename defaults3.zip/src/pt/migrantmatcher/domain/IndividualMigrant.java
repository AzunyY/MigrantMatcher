package pt.migrantmatcher.domain;

public class IndividualMigrant extends Migrant{
		
	protected IndividualMigrant(String name, int tel) {
		super();
		setTel(tel);
		setName(name);
	}

}
