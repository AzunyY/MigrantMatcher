package pt.migrantmatcher.domain;

public enum Type {
	ITEM,
	HOUSING
}
