package pt.migrantmatcher.plugins;

public interface SenderType {
	
	public void sendSMS(int num, String cod);
}
